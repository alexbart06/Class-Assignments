let rain = [];
let circleX = 0;
let circleY = 0;
let circleFade = 0;

function setup() {
  createCanvas(400, 400);

  for (let i = 0; i < 20; i++) {
    rain[i] = random(0, 400);
  }

  print(rain.length);
}

function draw() {
  background(30);

  noStroke();
  fill(50, 150, 50);
  rect(190, 125, 20, 35);

  fill(255, 130, 0);
  ellipse(200, 200, 150, 130);

  fill(0);
  triangle(160, 180, 180, 180, 170, 200);
  triangle(220, 180, 240, 180, 230, 200);

  arc(200, 215, 70, 40, 0, PI);

  stroke(150, 255, 0);
  strokeWeight(2);

  for (let i = 0; i < rain.length; i++) {
    line(i * 20, rain[i], i * 20, rain[i] + 10);

    rain[i] += 2;

    if (rain[i] > 400) {
      rain[i] = 0;
    }
  }

  noStroke();
  fill(150, 255, 0, circleFade);
  ellipse(circleX, circleY, 40, 40);

  circleFade -= 5;
}

function mousePressed() {
  rain[0] = mouseY;

  circleX = mouseX;
  circleY = mouseY;
  circleFade = 255;
}