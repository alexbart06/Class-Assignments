let balls = [];
let spikes = [];
let ground;
let hits = 0;

function setup() {
  createCanvas(600, 450);

  world.gravity.y = 10;

  ground = new Sprite(300, 430, 540, 30, 'static');
  ground.color = 'blue';

  for (let row = 0; row < 4; row++) {
    for (let col = 0; col < 7; col++) {

      let x = 80 + col * 70;

      if (row % 2 === 1) {
        x += 35;
      }

      let y = 150 + row * 70;

      let spike = new Sprite(x, y, 35, 'triangle', 'static');
      spike.color = 'blue';

      spikes.push(spike);
    }
  }
}

function draw() {
  background(220);

  fill(0);
  textSize(16);
  text("Click to drop balls", 20, 25);
  text("Press R to remove balls and reset triangle collision counter", 20, 45);
  text("Triangle collisions: " + hits, 20, 65);

  for (let ball of balls) {
    for (let spike of spikes) {
      if (ball.collides(spike)) {
        hits++;
      }
    }
  }
}

function mousePressed() {
  let x = constrain(mouseX, 50, 550);

  let ball = new Sprite(x, 90, 25);
  ball.color = 'red';
  ball.bounciness = 0.5;

  balls.push(ball);
}

function keyPressed() {
  if (key === 'r' || key === 'R') {
    for (let ball of balls) {
      ball.delete();
    }

    balls = [];
    hits = 0;
  }
}