let power = true;
let channel = 1;
let message = false;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(270);
  
  fill(20);
  rect(40, 35, 320, 330);
  fill(60);
  rect(65, 60, 270, 210);

  if (power) {
    if (channel === 1) {
      fill(300, 200, 320);
    } else {
      fill(105, 200, 60);
    }

    rect(75, 70, 250, 190);

    fill(30);
    textSize(24);
    textAlign(CENTER, CENTER);

    if (message) {
      text("This is the tv", 200, 165);
    } else {
      text("screen " + channel, 200, 165);
    }
  } else {
    fill(245);
    textSize(24);
    textAlign(CENTER, CENTER);
    text("OFF", 200, 165);
  }
  fill(30);
  rect(75, 300, 90, 40);

  fill(305, 120, 100);
  ellipse(210, 320, 40, 40);

  fill(80);
  rect(250, 300, 95, 40);

  textSize(13);
  textAlign(CENTER, CENTER);

  fill(300);
  text("ON/OFF", 120, 320);
  text("What is this?", 297, 320);

  fill(30);
  text("+/-", 210, 320);

  textSize(12);
  text("Hover over What is this? and press q", 200, 387);
}

function mousePressed() {
  if (mouseX > 75 && mouseX < 165 &&
      mouseY > 300 && mouseY < 340) {
    power = !power;
  }
  if (dist(mouseX, mouseY, 210, 320) < 20) {
    if (channel === 1) {
      channel = 2;
    } else {
      channel = 1;
    }
  }
}
function keyPressed() {
  if (mouseX > 260 && mouseX < 335 &&
      mouseY > 300 && mouseY < 340 &&
      key === 'q') {
    message = !message;
  }
}